#!/usr/bin/python
#
# Tests the functionality of history implement

import atexit, proc_check, time
from testutils import *

console = setup_tests()

# ensure that shell prints expected prompt
expect_prompt()

# exuecute the program
sendline("echo hello")

# execute the history builtin command
sendline("history")

expect("2 history")

sendline("echo hello | rev")
sendline("!!")
expect("olleh")

sendline("ps")

sendline("!1")
expect("hello")

sendline("ps -a")
sendline("!e")

expect("hello")

sendline("exit");

# ensure that no extra characters are output after exiting
expect_exact("exit\r\n", "Shell output extraneous characters")

test_success()
